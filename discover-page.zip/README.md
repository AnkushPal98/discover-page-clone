# CODE FLOW

Step 1
App.js is the starting javascript file in which I have used routing for navigating to DiscoverPage component and CardDetails component.

step 2
Inside DiscoverPage component I have implemeted the logic for handling the main header and placing the DiscoverCard as per the requirement.

Step 3
Modal component is implemented for handling the logic for filter button which is created inside the main header of DiscoverPage component.

step 4
DiscoverCard component is implemented for navigating to CardDetails component on card clicked.

step 5
CardDetails component is implemented for showing the complete details of the cards.

step 6
CardDetailsHeader component -> Implemented for the header of CardDetails page.
ChatBar component -> Implemented for the chat bar of CardDetails page.
ShareModal component -> Implemented for for share button of CardDetails page.



# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.